const tg=window.Telegram?.WebApp;tg?.ready();tg?.expand();
const me=tg?.initDataUnsafe?.user||{id:999999,first_name:'Demo',username:'demo'};
let challengeId=null;
const $=x=>document.getElementById(x);
async function session(){await fetch('/api/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user:me})});}
async function newChallenge(){
 const c=await fetch('/api/challenge').then(r=>r.json());challengeId=c.id;
 $('challenge').innerHTML=
 `<div class="stat">BPM<b>${c.bpm}</b></div>`+
 `<div class="stat">Gênero<b>${c.genre}</b></div>`+
 `<div class="stat">Tom<b>${c.key_sig}</b></div>`+
 `<div class="stat">Obrigatório<b>${c.required}</b></div>`+
 `<div class="stat">Proibido<b>${c.forbidden}</b></div>`+
 `<div class="stat">Tempo<b>${c.minutes} min</b></div>`;
 $('subs').innerHTML=''; $('sendMsg').textContent='';
}
async function submitBeat(){
 if(!challengeId){$('sendMsg').textContent='Crie um desafio primeiro.';return}
 const fileId=$('fileId').value.trim();if(!fileId){$('sendMsg').textContent='Informe o file_id.';return}
 const r=await fetch('/api/challenge/'+challengeId+'/submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:me.id,fileId,fileName:$('fileName').value||'Beat'})}).then(r=>r.json());
 $('sendMsg').className=r.ok?'ok':'error';$('sendMsg').textContent=r.message||r.error;
}
async function loadSubmissions(){
 if(!challengeId)return;
 const rows=await fetch('/api/challenge/'+challengeId+'/submissions').then(r=>r.json());
 $('subs').innerHTML=rows.map(x=>`<div class="card"><div class="row"><b>${x.name}</b><span>❤️ ${x.likes}</span></div><small>${x.file_name}</small><br><button onclick="vote(${x.id})">❤️ Votar</button></div>`).join('')||'Nenhum beat enviado ainda.';
}
async function vote(id){const r=await fetch('/api/submission/'+id+'/vote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voterId:me.id})}).then(r=>r.json());alert(r.ok?'Voto registrado!':r.error);loadSubmissions()}
async function ranking(){const rows=await fetch('/api/ranking').then(r=>r.json());$('rank').innerHTML=rows.map((x,i)=>`<div class="card row"><span>${i+1}. ${x.name}</span><b>${x.xp} XP • Nível ${x.level}</b></div>`).join('')}
async function profile(){const x=await fetch('/api/profile/'+me.id).then(r=>r.json());alert(`🎧 ${x.first_name}\\n⭐ ${x.xp} XP\\n🏅 Nível ${x.level}\\n🎵 Beats: ${x.submissions}\\n🏆 Votos recebidos: ${x.wins}`)}
session().then(newChallenge);