import 'dotenv/config';
import express from 'express';
import TelegramBot from 'node-telegram-bot-api';
import Database from 'better-sqlite3';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=Number(process.env.PORT||3000);
const BOT_TOKEN=process.env.BOT_TOKEN;
const WEBAPP_URL=process.env.WEBAPP_URL;

const db=new Database(path.join(__dirname,'..','beat-challenge.sqlite'));
db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY,
 username TEXT,
 first_name TEXT,
 xp INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS challenges(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 bpm INTEGER NOT NULL,
 genre TEXT NOT NULL,
 key_sig TEXT NOT NULL,
 required TEXT NOT NULL,
 forbidden TEXT NOT NULL,
 minutes INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS submissions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 challenge_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL,
 file_id TEXT NOT NULL,
 file_name TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(challenge_id,user_id)
);
CREATE TABLE IF NOT EXISTS votes(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 submission_id INTEGER NOT NULL,
 voter_id INTEGER NOT NULL,
 value INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(submission_id,voter_id)
);
`);

const genres=['Trap','Drill','Boom Bap','Grime','Lo-fi Hip Hop','R&B','Phonk'];
const keys=['Am','Em','Dm','F#m','Cm','Gm','Bm'];
const required=['808','Piano','Guitarra','Synth','Strings','Vocal chop','Percussão'];
const forbidden=['808','Hi-hat','Piano','Synth','Guitarra','Strings','Vocal chop'];

function user(u){
 let x=db.prepare('SELECT * FROM users WHERE id=?').get(u.id);
 if(!x) db.prepare('INSERT INTO users(id,username,first_name) VALUES(?,?,?)').run(u.id,u.username||null,u.first_name||'');
 else db.prepare('UPDATE users SET username=?,first_name=? WHERE id=?').run(u.username||null,u.first_name||'',u.id);
 return db.prepare('SELECT * FROM users WHERE id=?').get(u.id);
}
function challenge(){
 const c={
  bpm:[70,75,80,90,100,110,120,130,140,150,160][Math.floor(Math.random()*11)],
  genre:genres[Math.floor(Math.random()*genres.length)],
  key_sig:keys[Math.floor(Math.random()*keys.length)],
  required:required[Math.floor(Math.random()*required.length)],
  forbidden:forbidden[Math.floor(Math.random()*forbidden.length)],
  minutes:[15,30,45,60][Math.floor(Math.random()*4)]
 };
 const info=db.prepare('INSERT INTO challenges(bpm,genre,key_sig,required,forbidden,minutes) VALUES(?,?,?,?,?,?)')
  .run(c.bpm,c.genre,c.key_sig,c.required,c.forbidden,c.minutes);
 return {...c,id:info.lastInsertRowid};
}
app.use(express.json());
app.use(express.static(path.join(__dirname,'..','public')));

app.get('/api/challenge',(_req,res)=>res.json(challenge()));

app.post('/api/session',(req,res)=>{
 const u=req.body?.user;
 if(!u?.id)return res.status(400).json({error:'Usuário ausente.'});
 res.json(user(u));
});

app.get('/api/profile/:id',(req,res)=>{
 const u=db.prepare('SELECT id,username,first_name,xp,created_at FROM users WHERE id=?').get(Number(req.params.id));
 if(!u)return res.status(404).json({error:'Usuário não encontrado'});
 const submissions=db.prepare('SELECT COUNT(*) c FROM submissions WHERE user_id=?').get(u.id).c;
 const wins=db.prepare(`
  SELECT COUNT(*) c FROM votes v JOIN submissions s ON s.id=v.submission_id
  WHERE s.user_id=? AND v.value=1`).get(u.id).c;
 res.json({...u,submissions,wins,level:Math.floor(u.xp/100)+1});
});

app.get('/api/ranking',(_req,res)=>{
 res.json(db.prepare(`
 SELECT COALESCE(username,first_name,'Beatmaker') name,xp,
        CAST(xp/100 AS INTEGER)+1 level
 FROM users ORDER BY xp DESC LIMIT 20`).all());
});

app.post('/api/challenge/:id/submit',(req,res)=>{
 const {userId,fileId,fileName}=req.body||{};
 const challengeId=Number(req.params.id);
 if(!userId||!fileId)return res.status(400).json({error:'Envie o ID do usuário e o file_id do áudio.'});
 const c=db.prepare('SELECT * FROM challenges WHERE id=?').get(challengeId);
 if(!c)return res.status(404).json({error:'Desafio não encontrado.'});
 try{
  db.prepare('INSERT INTO submissions(challenge_id,user_id,file_id,file_name) VALUES(?,?,?,?)')
   .run(challengeId,userId,fileId,fileName||'beat');
  db.prepare('UPDATE users SET xp=xp+25 WHERE id=?').run(userId);
  res.json({ok:true,xp:25,message:'Beat enviado! Você ganhou 25 XP.'});
 }catch(e){res.status(400).json({error:'Você já enviou um beat para este desafio.'});}
});

app.get('/api/challenge/:id/submissions',(req,res)=>{
 const id=Number(req.params.id);
 res.json(db.prepare(`
 SELECT s.id,s.file_name,s.created_at,
 COALESCE(u.username,u.first_name,'Beatmaker') name,
 (SELECT COUNT(*) FROM votes v WHERE v.submission_id=s.id AND v.value=1) likes
 FROM submissions s JOIN users u ON u.id=s.user_id
 WHERE s.challenge_id=? ORDER BY likes DESC,s.id DESC`).all(id));
});

app.post('/api/submission/:id/vote',(req,res)=>{
 const submissionId=Number(req.params.id), voterId=Number(req.body?.voterId);
 if(!voterId)return res.status(400).json({error:'Votante ausente.'});
 const s=db.prepare('SELECT * FROM submissions WHERE id=?').get(submissionId);
 if(!s)return res.status(404).json({error:'Beat não encontrado.'});
 if(s.user_id===voterId)return res.status(400).json({error:'Você não pode votar no próprio beat.'});
 try{
  db.prepare('INSERT INTO votes(submission_id,voter_id,value) VALUES(?,?,1)').run(submissionId,voterId);
  db.prepare('UPDATE users SET xp=xp+5 WHERE id=?').run(s.user_id);
  res.json({ok:true});
 }catch(e){res.status(400).json({error:'Você já votou neste beat.'});}
});

app.listen(PORT,()=>console.log(`Beat Challenge em http://localhost:${PORT}`));

if(BOT_TOKEN){
 const bot=new TelegramBot(BOT_TOKEN,{polling:true});
 bot.onText(/\/start/,msg=>{
  user(msg.from);
  const opts=WEBAPP_URL?{reply_markup:{inline_keyboard:[
   [{text:'🎯 Abrir Beat Challenge',web_app:{url:WEBAPP_URL}}]
  ]}}:{};
  bot.sendMessage(msg.chat.id,
   `🎧 BEAT CHALLENGE\\n\\nOlá, ${msg.from.first_name||'beatmaker'}!\\n\\nCrie beats seguindo desafios de BPM, gênero, tonalidade e regras especiais.\\n\\nVocê ganha XP por participar e votar.`,opts);
 });
 bot.on('audio',msg=>{
  user(msg.from);
  bot.sendMessage(msg.chat.id,
   '🎵 Recebi seu áudio! Para associá-lo a um desafio, abra o Beat Challenge e envie o file_id do áudio pelo fluxo de submissão.\\n\\nDica: o Telegram identifica o arquivo por um file_id.');
 });
}
